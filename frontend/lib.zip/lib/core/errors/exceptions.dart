class ServerException implements Exception {}

class UnauthorizedException implements Exception {}

class EmailNotVerifiedException implements Exception {}
